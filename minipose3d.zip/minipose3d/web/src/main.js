import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import './style.css';
import { Timeline } from './anim.js';
import { SpringSystem, PRESETS, colliderCenter } from './physics.js';

const $ = (id) => document.getElementById(id);

// ───────────────────────── state ─────────────────────────
const tl = new Timeline();
const physics = new SpringSystem();
let model = null;
let bones = [];
let boneMap = new Map();
let selected = null;
const st = { frame: 0, playing: false, live: true, showBones: true };

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

// ───────────────────────── scene ─────────────────────────
const viewport = $('viewport');
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x15171c);
const camera = new THREE.PerspectiveCamera(40, 1, 0.01, 1000);
camera.position.set(0, 1.2, 3.5);
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.4));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(2, 4, 3);
scene.add(sun);
const grid = new THREE.GridHelper(10, 20, 0x4a5060, 0x2a2f3a);
scene.add(grid);

const orbit = new OrbitControls(camera, canvas);
orbit.enableDamping = true;
orbit.target.set(0, 1, 0);

const tc = new TransformControls(camera, canvas);
tc.setSize(1.1);
scene.add(tc.getHelper ? tc.getHelper() : tc);
tc.addEventListener('dragging-changed', (e) => {
  orbit.enabled = !e.value;
});

function resize() {
  const w = viewport.clientWidth;
  const h = viewport.clientHeight;
  if (!w || !h) return;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(viewport);
resize();

// ───────────────────────── bone overlay ─────────────────────────
const overlay = new THREE.Group();
scene.add(overlay);
const handleGeo = new THREE.BufferGeometry();
const handles = new THREE.Points(
  handleGeo,
  new THREE.PointsMaterial({ size: 11, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true }),
);
handles.renderOrder = 999;
handles.frustumCulled = false;
const lineGeo = new THREE.BufferGeometry();
const lines = new THREE.LineSegments(
  lineGeo,
  new THREE.LineBasicMaterial({ color: 0x7aa2ff, depthTest: false, transparent: true, opacity: 0.45 }),
);
lines.renderOrder = 998;
lines.frustumCulled = false;
overlay.add(handles, lines);

const COL = {
  n: new THREE.Color(0xcfd6e6),
  k: new THREE.Color(0xffa94d),
  s: new THREE.Color(0x4dd8ff),
  sel: new THREE.Color(0xffe14d),
};
let lineIdx = []; // [boneIndex, parentIndex]

function buildOverlay() {
  handleGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(bones.length * 3), 3));
  handleGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(bones.length * 3), 3));
  const index = new Map(bones.map((b, i) => [b, i]));
  lineIdx = [];
  bones.forEach((b, i) => {
    if (index.has(b.parent)) lineIdx.push([i, index.get(b.parent)]);
  });
  lineGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(lineIdx.length * 6), 3));
}

const _v = new THREE.Vector3();
function updateOverlay() {
  overlay.visible = st.showBones && !!model;
  if (!overlay.visible) return;
  const pos = handleGeo.attributes.position;
  const col = handleGeo.attributes.color;
  if (!pos) return;
  for (let i = 0; i < bones.length; i++) {
    const b = bones[i];
    _v.setFromMatrixPosition(b.matrixWorld);
    pos.setXYZ(i, _v.x, _v.y, _v.z);
    const c = b === selected ? COL.sel : physics.isSimulated(b) ? COL.s : tl.tracks.has(b.name) ? COL.k : COL.n;
    col.setXYZ(i, c.r, c.g, c.b);
  }
  pos.needsUpdate = true;
  col.needsUpdate = true;
  const lp = lineGeo.attributes.position;
  for (let i = 0; i < lineIdx.length; i++) {
    const [a, p] = lineIdx[i];
    _v.setFromMatrixPosition(bones[a].matrixWorld);
    lp.setXYZ(i * 2, _v.x, _v.y, _v.z);
    _v.setFromMatrixPosition(bones[p].matrixWorld);
    lp.setXYZ(i * 2 + 1, _v.x, _v.y, _v.z);
  }
  lp.needsUpdate = true;
  for (const c of physics.colliders) {
    if (!c.mesh) continue;
    colliderCenter(c, _v);
    c.mesh.position.copy(_v);
    c.mesh.scale.setScalar(Math.max(c.radius * physics.unit, 1e-4));
  }
}

// ───────────────────────── model loading ─────────────────────────
function clearModel() {
  tc.detach();
  selected = null;
  if (model) {
    scene.remove(model);
    model.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
    });
  }
  for (const c of physics.colliders) if (c.mesh) overlay.remove(c.mesh);
  physics.clear();
  tl.clear();
  model = null;
  bones = [];
  boneMap = new Map();
  st.frame = 0;
  st.playing = false;
  $('btnPlay').textContent = '▶';
}

function setModel(root) {
  clearModel();
  model = root;
  scene.add(model);
  model.updateMatrixWorld(true);

  const set = new Set();
  model.traverse((o) => {
    if (o.isSkinnedMesh && o.skeleton) o.skeleton.bones.forEach((b) => set.add(b));
    if (o.isBone) set.add(o);
    if (o.isMesh) o.frustumCulled = false;
  });
  bones = [];
  model.traverse((o) => {
    if (set.has(o)) bones.push(o);
  });

  // Unique names (needed to address bones in keyframes). Only duplicates/empty names are touched.
  const seen = new Map();
  for (const b of bones) {
    let n = b.name || 'bone';
    if (seen.has(n)) {
      let k = seen.get(n) + 1;
      while (seen.has(`${n}_${k}`)) k++;
      seen.set(n, k);
      n = `${n}_${k}`;
    }
    seen.set(n, seen.get(n) || 1);
    if (b.name !== n) b.name = n;
  }

  for (const b of bones) {
    let d = 0;
    for (let p = b.parent; p; p = p.parent) if (set.has(p)) d++;
    b.userData.depth = d;
    b.userData.rest = { p: b.position.clone(), q: b.quaternion.clone(), s: b.scale.clone() };
    boneMap.set(b.name, b);
  }

  // Fit camera + scale physics to model size.
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const height = size.y > 1e-6 ? size.y : Math.max(size.x, size.z, 1);
  physics.unit = height / 1.6;
  grid.scale.setScalar(physics.unit);
  grid.position.y = box.min.y;
  const dist = (height * 0.5) / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * 1.4 + size.z * 0.5;
  camera.position.set(center.x, center.y, center.z + dist);
  camera.near = dist / 200;
  camera.far = dist * 200;
  camera.updateProjectionMatrix();
  orbit.target.copy(center);
  orbit.update();

  buildOverlay();
  buildList();
  select(null);
  setFrame(0);
  if (!bones.length) toast('No skeleton found in this model');
}

async function importFile(file) {
  const lower = file.name.toLowerCase();
  if (lower.endsWith('.json')) {
    if (!model) return toast('Import a model first');
    loadProject(JSON.parse(await file.text()));
    return;
  }
  toast(`Loading ${file.name}…`);
  const buf = await file.arrayBuffer();
  let root;
  if (lower.endsWith('.fbx')) {
    root = new FBXLoader().parse(buf, '');
  } else {
    const loader = new GLTFLoader();
    loader.setMeshoptDecoder(MeshoptDecoder);
    root = (await new Promise((res, rej) => loader.parse(buf, '', res, rej))).scene;
  }
  setModel(root);
  if (bones.length) toast(`${bones.length} bones loaded`);
}

// ───────────────────────── selection ─────────────────────────
function select(b) {
  selected = b;
  if (b && !physics.isSimulated(b)) tc.attach(b);
  else {
    tc.detach();
    if (b) toast('Physics bone — remove physics to pose it by hand');
  }
  $('selName').textContent = b ? b.name : 'No bone selected';
  refreshList();
  refreshPhysicsUI();
}

function pickAt(cx, cy) {
  if (!model) return;
  const r = canvas.getBoundingClientRect();
  let best = null;
  let bd = 30 * 30;
  for (const b of bones) {
    _v.setFromMatrixPosition(b.matrixWorld).project(camera);
    if (_v.z > 1) continue;
    const sx = (_v.x * 0.5 + 0.5) * r.width + r.left;
    const sy = (-_v.y * 0.5 + 0.5) * r.height + r.top;
    const d = (sx - cx) ** 2 + (sy - cy) ** 2;
    if (d < bd) {
      bd = d;
      best = b;
    }
  }
  if (best) select(best);
}

let down = null;
const pts = new Set();
canvas.addEventListener('pointerdown', (e) => {
  pts.add(e.pointerId);
  down = pts.size === 1 ? { x: e.clientX, y: e.clientY, t: performance.now(), gizmo: tc.dragging || tc.axis !== null } : null;
});
canvas.addEventListener('pointerup', (e) => {
  pts.delete(e.pointerId);
  if (!down) return;
  const d = down;
  down = null;
  if (d.gizmo) return;
  if (Math.hypot(e.clientX - d.x, e.clientY - d.y) < 8 && performance.now() - d.t < 500) pickAt(e.clientX, e.clientY);
});
canvas.addEventListener('pointercancel', (e) => {
  pts.delete(e.pointerId);
  down = null;
});

// ───────────────────────── bone list ─────────────────────────
const listEl = $('boneList');
function buildList() {
  listEl.innerHTML = '';
  bones.forEach((b, i) => {
    const li = document.createElement('li');
    li.dataset.i = i;
    li.style.paddingLeft = `${8 + b.userData.depth * 10}px`;
    li.textContent = b.name;
    listEl.appendChild(li);
  });
  refreshList();
}
function refreshList() {
  const q = $('search').value.trim().toLowerCase();
  for (const li of listEl.children) {
    const b = bones[+li.dataset.i];
    li.hidden = !!q && !b.name.toLowerCase().includes(q);
    li.className = [b === selected ? 'sel' : '', physics.isSimulated(b) ? 'sim' : '', tl.tracks.has(b.name) ? 'key' : ''].join(' ');
  }
}
listEl.addEventListener('click', (e) => {
  const li = e.target.closest('li');
  if (li) select(bones[+li.dataset.i]);
});
$('search').addEventListener('input', refreshList);

// ───────────────────────── toolbar ─────────────────────────
$('btnMenu').onclick = () => $('drawer').classList.toggle('hidden');
$('btnImport').onclick = () => $('file').click();
$('btnBones').onclick = (e) => {
  st.showBones = !st.showBones;
  e.currentTarget.classList.toggle('on', st.showBones);
};
document.querySelectorAll('#tools [data-mode]').forEach((btn) => {
  btn.onclick = () => {
    tc.setMode(btn.dataset.mode);
    document.querySelectorAll('#tools [data-mode]').forEach((b) => b.classList.toggle('on', b === btn));
  };
});
tc.setMode('rotate');
$('btnSpace').onclick = (e) => {
  const next = tc.space === 'world' ? 'local' : 'world';
  tc.setSpace(next);
  e.currentTarget.textContent = next === 'world' ? 'World' : 'Local';
};
$('btnFocus').onclick = () => {
  if (!selected) return toast('Select a bone first');
  const p = new THREE.Vector3().setFromMatrixPosition(selected.matrixWorld);
  const dir = camera.position.clone().sub(orbit.target).normalize();
  orbit.target.copy(p);
  camera.position.copy(p).addScaledVector(dir, physics.unit * 0.7);
  orbit.update();
};
function resetBone(b) {
  const r = b.userData.rest;
  if (!r) return;
  b.position.copy(r.p);
  b.quaternion.copy(r.q);
  b.scale.copy(r.s);
}
$('btnResetBone').onclick = () => {
  if (!selected) return toast('Select a bone first');
  if (physics.isSimulated(selected)) return toast('Physics bone');
  resetBone(selected);
};

$('file').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  try {
    await importFile(f);
  } catch (err) {
    console.error(err);
    toast(`Import failed: ${err.message || err}`);
  }
});

// ───────────────────────── tabs ─────────────────────────
document.querySelectorAll('#tabs [data-tab]').forEach((btn) => {
  btn.onclick = () => {
    document.querySelectorAll('#tabs [data-tab]').forEach((b) => b.classList.toggle('on', b === btn));
    for (const id of ['bones', 'physics', 'project']) $(`tab-${id}`).hidden = id !== btn.dataset.tab;
  };
});

// ───────────────────────── timeline UI ─────────────────────────
const slider = $('frameSlider');
function setFrame(f) {
  st.frame = f;
  slider.max = Math.max(tl.length - 1, 1);
  slider.value = Math.round(f);
  $('frameLbl').textContent = `${Math.round(f)} / ${tl.length - 1}`;
}
function scrub(f) {
  setFrame(f);
  if (!model) return;
  tl.apply(boneMap, f, (b) => physics.isSimulated(b));
  physics.reset(model);
}
slider.addEventListener('input', () => scrub(+slider.value));

$('btnStart').onclick = () => scrub(0);
$('btnPlay').onclick = () => {
  st.playing = !st.playing;
  $('btnPlay').textContent = st.playing ? '⏸' : '▶';
  if (st.playing) {
    if (st.frame >= tl.length - 1) setFrame(0);
    physics.reset(model);
  }
};
$('btnKey').onclick = () => {
  if (!selected) return toast('Select a bone first');
  if (physics.isSimulated(selected)) return toast('Physics bone — key its parent instead');
  tl.keyBone(selected, Math.round(st.frame));
  refreshList();
  toast(`Key set @ ${Math.round(st.frame)}`);
};
$('btnDelKey').onclick = () => {
  if (!selected) return toast('Select a bone first');
  if (tl.removeKey(selected.name, Math.round(st.frame))) refreshList();
  else toast('No key here');
};

const strip = $('strip');
const sctx = strip.getContext('2d');
function drawStrip() {
  const w = strip.clientWidth;
  const h = strip.clientHeight;
  const dpr = window.devicePixelRatio || 1;
  if (strip.width !== Math.round(w * dpr) || strip.height !== Math.round(h * dpr)) {
    strip.width = Math.round(w * dpr);
    strip.height = Math.round(h * dpr);
  }
  sctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  sctx.clearRect(0, 0, w, h);
  const span = Math.max(1, tl.length - 1);
  const X = (f) => 8 + ((w - 16) * f) / span;
  sctx.fillStyle = '#2c313c';
  sctx.fillRect(8, h / 2 - 1, w - 16, 2);
  for (let f = 0; f <= span; f += 10) sctx.fillRect(X(f) - 0.5, h / 2 - 5, 1, 10);
  const diamond = (x, r, color) => {
    sctx.fillStyle = color;
    sctx.beginPath();
    sctx.moveTo(x, h / 2 - r);
    sctx.lineTo(x + r, h / 2);
    sctx.lineTo(x, h / 2 + r);
    sctx.lineTo(x - r, h / 2);
    sctx.closePath();
    sctx.fill();
  };
  const all = new Set();
  for (const arr of tl.tracks.values()) for (const k of arr) all.add(k.f);
  for (const f of all) diamond(X(f), 4, '#6b5a3a');
  const mine = selected ? tl.tracks.get(selected.name) : null;
  if (mine) for (const k of mine) diamond(X(k.f), 6, '#ffb020');
  sctx.fillStyle = '#4dd8ff';
  sctx.fillRect(X(st.frame) - 1, 2, 2, h - 4);
}
function stripScrub(e) {
  const r = strip.getBoundingClientRect();
  const span = Math.max(1, tl.length - 1);
  const f = Math.round(THREE.MathUtils.clamp(((e.clientX - r.left - 8) / (r.width - 16)) * span, 0, span));
  scrub(f);
}
strip.addEventListener('pointerdown', (e) => {
  strip.setPointerCapture(e.pointerId);
  stripScrub(e);
  strip.onpointermove = stripScrub;
});
strip.addEventListener('pointerup', () => {
  strip.onpointermove = null;
});

// ───────────────────────── physics UI ─────────────────────────
const PARAMS = { stiffness: [0, 4, 0.05], drag: [0, 1, 0.01], gravity: [0, 2, 0.05], radius: [0, 0.1, 0.005] };
const sliderEls = {};
for (const [k, [mn, mx, stp]] of Object.entries(PARAMS)) {
  const wrap = document.createElement('div');
  wrap.className = 'sl';
  const lab = document.createElement('label');
  lab.innerHTML = `<span>${k === 'radius' ? 'Hit radius' : k[0].toUpperCase() + k.slice(1)}</span><b></b>`;
  const inp = document.createElement('input');
  inp.type = 'range';
  inp.min = mn;
  inp.max = mx;
  inp.step = stp;
  const out = lab.querySelector('b');
  inp.addEventListener('input', () => {
    const g = selected && physics.groupOf(selected);
    if (!g) return;
    g.params[k] = +inp.value;
    out.textContent = (+inp.value).toFixed(2);
  });
  wrap.append(lab, inp);
  $('sliders').appendChild(wrap);
  sliderEls[k] = { inp, out };
}

function refreshPhysicsUI() {
  const g = selected ? physics.groupOf(selected) : null;
  $('physInfo').textContent = !selected
    ? 'Select a bone first (tap a dot, or pick from the Bones tab).'
    : g
      ? `Physics ON — ${g.root.name} + ${g.joints.length - 1} child bone(s)`
      : `${selected.name}: physics off`;
  for (const [k, { inp, out }] of Object.entries(sliderEls)) {
    inp.disabled = !g;
    const v = g ? g.params[k] : PRESETS.hair[k];
    inp.value = v;
    out.textContent = (+v).toFixed(2);
  }
  rebuildColliderList();
}

function enablePhysics(preset) {
  if (!selected) return toast('Select a bone first');
  if (!selected.parent) return toast("That bone has no parent to hang from");
  physics.add(selected, PRESETS[preset]);
  physics.reset(model);
  select(selected);
  toast(`${preset} physics on`);
}
$('phHair').onclick = () => enablePhysics('hair');
$('phSkirt').onclick = () => enablePhysics('skirt');
$('phOff').onclick = () => {
  if (!selected || !physics.isSimulated(selected)) return toast('Not a physics bone');
  physics.remove(selected);
  select(selected);
};
$('phReset').onclick = () => physics.reset(model);
$('phLive').onchange = (e) => {
  st.live = e.target.checked;
};

function makeColliderMesh(c) {
  c.mesh = new THREE.Mesh(
    new THREE.SphereGeometry(1, 14, 10),
    new THREE.MeshBasicMaterial({ color: 0x4dd8ff, wireframe: true, transparent: true, opacity: 0.5, depthTest: false }),
  );
  c.mesh.renderOrder = 997;
  c.mesh.frustumCulled = false;
  overlay.add(c.mesh);
}
function rebuildColliderList() {
  const box = $('colList');
  box.innerHTML = '';
  for (const c of physics.colliders) {
    const el = document.createElement('div');
    el.className = 'col';
    el.innerHTML = `<div class="top"><span></span><button>✕</button></div>
      <div class="sl"><label><span>Radius</span></label><input class="r" type="range" min="0.01" max="0.6" step="0.005"></div>
      <div class="sl"><label><span>Position along bone</span></label><input class="a" type="range" min="0" max="1" step="0.05"></div>`;
    el.querySelector('span').textContent = c.bone.name;
    const r = el.querySelector('.r');
    const a = el.querySelector('.a');
    r.value = c.radius;
    a.value = c.along;
    r.oninput = () => (c.radius = +r.value);
    a.oninput = () => (c.along = +a.value);
    el.querySelector('button').onclick = () => {
      overlay.remove(c.mesh);
      physics.removeCollider(c);
      rebuildColliderList();
    };
    box.appendChild(el);
  }
}
$('colAdd').onclick = () => {
  if (!selected) return toast('Select a bone first');
  makeColliderMesh(physics.addCollider(selected, 0.1, 0.5));
  rebuildColliderList();
};

// ───────────────────────── project tab ─────────────────────────
$('pjKeyAll').onclick = () => {
  if (!model) return;
  const f = Math.round(st.frame);
  for (const b of bones) if (!physics.isSimulated(b)) tl.keyBone(b, f);
  refreshList();
  toast(`Keyed ${bones.length} bones @ ${f}`);
};
$('pjClear').onclick = () => {
  if (!tl.tracks.size) return;
  if (confirm('Delete all keyframes?')) {
    tl.clear();
    refreshList();
  }
};
$('pjRest').onclick = () => {
  for (const b of bones) resetBone(b);
  physics.reset(model);
};
$('inLen').onchange = (e) => {
  tl.length = THREE.MathUtils.clamp(parseInt(e.target.value, 10) || 120, 10, 3000);
  e.target.value = tl.length;
  setFrame(Math.min(st.frame, tl.length - 1));
};
$('inFps').onchange = (e) => {
  tl.fps = THREE.MathUtils.clamp(parseInt(e.target.value, 10) || 30, 1, 60);
  e.target.value = tl.fps;
};
$('inSmooth').onchange = (e) => {
  tl.smooth = e.target.checked;
};

function projectJSON() {
  return {
    v: 1,
    timeline: tl.toJSON(),
    physics: {
      groups: physics.groups.map((g) => ({ root: g.root.name, params: { ...g.params } })),
      colliders: physics.colliders.map((c) => ({ bone: c.bone.name, radius: c.radius, along: c.along })),
    },
  };
}
function loadProject(o) {
  tl.fromJSON(o.timeline || {});
  $('inLen').value = tl.length;
  $('inFps').value = tl.fps;
  $('inSmooth').checked = tl.smooth;
  for (const c of physics.colliders) if (c.mesh) overlay.remove(c.mesh);
  for (const g of [...physics.groups]) physics.remove(g.root);
  physics.colliders = [];
  let missing = 0;
  for (const g of o.physics?.groups || []) {
    const b = boneMap.get(g.root);
    if (b) physics.add(b, g.params);
    else missing++;
  }
  for (const c of o.physics?.colliders || []) {
    const b = boneMap.get(c.bone);
    if (b) makeColliderMesh(physics.addCollider(b, c.radius, c.along));
    else missing++;
  }
  scrub(0);
  select(selected);
  toast(missing ? `Project loaded (${missing} bones not found — different model?)` : 'Project loaded');
}
$('pjSave').onclick = () => {
  if (!model) return toast('Import a model first');
  saveBytes('minipose_project.json', new TextEncoder().encode(JSON.stringify(projectJSON())), 'application/json');
};

// ───────────────────────── export ─────────────────────────
function saveBytes(name, data, mime) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  if (window.Android && window.Android.saveBase64) {
    let bin = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    window.Android.saveBase64(name, btoa(bin), mime);
  } else {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([bytes], { type: mime }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast(`Saved ${name}`);
  }
}

$('btnExport').onclick = async () => {
  if (!model) return toast('Import a model first');
  toast('Exporting…');
  // Export in rest pose + the keyframe clip, so the file is your original rig with animation attached.
  const snap = bones.map((b) => [b.position.clone(), b.quaternion.clone(), b.scale.clone()]);
  try {
    for (const b of bones) resetBone(b);
    model.updateMatrixWorld(true);
    const clip = tl.toClip(boneMap);
    const result = await new GLTFExporter().parseAsync(model, {
      binary: true,
      animations: clip.tracks.length ? [clip] : [],
    });
    saveBytes('minipose_export.glb', result, 'model/gltf-binary');
  } catch (err) {
    console.error(err);
    toast(`Export failed: ${err.message || err}`);
  } finally {
    bones.forEach((b, i) => {
      b.position.copy(snap[i][0]);
      b.quaternion.copy(snap[i][1]);
      b.scale.copy(snap[i][2]);
    });
  }
};

// ───────────────────────── main loop ─────────────────────────
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min((now - last) / 1000, 0.1);
  last = now;
  if (model) {
    if (st.playing) {
      st.frame += dt * tl.fps;
      if (st.frame >= tl.length - 1) st.frame = 0;
      setFrame(st.frame);
      tl.apply(boneMap, st.frame, (b) => physics.isSimulated(b));
    }
    model.updateMatrixWorld(true);
    if (st.live || st.playing) physics.update(dt);
  }
  orbit.update();
  updateOverlay();
  drawStrip();
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);
setFrame(0);
refreshPhysicsUI();
