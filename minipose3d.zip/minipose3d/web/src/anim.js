// Keyframe timeline. Each key stores the full local transform (position, rotation, scale)
// of one bone at one frame. The rig itself is never modified.
import * as THREE from 'three';

const _a = new THREE.Quaternion();
const _b = new THREE.Quaternion();
const _va = new THREE.Vector3();
const _vb = new THREE.Vector3();
const ease = (t) => t * t * (3 - 2 * t);

export class Timeline {
  constructor() {
    this.fps = 30;
    this.length = 120; // frames
    this.smooth = true;
    this.tracks = new Map(); // boneName -> [{ f, p, q, s }] sorted by f
  }

  clear() {
    this.tracks.clear();
  }

  keyBone(bone, f) {
    const arr = this.tracks.get(bone.name) || [];
    const key = {
      f,
      p: bone.position.toArray(),
      q: bone.quaternion.toArray(),
      s: bone.scale.toArray(),
    };
    const i = arr.findIndex((k) => k.f === f);
    if (i >= 0) arr[i] = key;
    else {
      arr.push(key);
      arr.sort((x, y) => x.f - y.f);
    }
    this.tracks.set(bone.name, arr);
  }

  removeKey(name, f) {
    const arr = this.tracks.get(name);
    if (!arr) return false;
    const i = arr.findIndex((k) => k.f === f);
    if (i < 0) return false;
    arr.splice(i, 1);
    if (!arr.length) this.tracks.delete(name);
    return true;
  }

  hasKey(name, f) {
    const a = this.tracks.get(name);
    return !!a && a.some((k) => k.f === f);
  }

  /** Pose every keyed bone at frame f. `skip(bone)` returns true for bones driven by physics. */
  apply(boneMap, f, skip) {
    for (const [name, arr] of this.tracks) {
      const b = boneMap.get(name);
      if (!b || (skip && skip(b))) continue;
      this._pose(arr, f, b);
    }
  }

  _set(b, k) {
    b.position.fromArray(k.p);
    b.quaternion.fromArray(k.q);
    b.scale.fromArray(k.s);
  }

  _pose(arr, f, b) {
    const first = arr[0];
    const last = arr[arr.length - 1];
    if (arr.length === 1 || f <= first.f) return this._set(b, first);
    if (f >= last.f) return this._set(b, last);
    let i = 0;
    while (arr[i + 1].f <= f) i++;
    const a = arr[i];
    const c = arr[i + 1];
    let t = (f - a.f) / (c.f - a.f);
    if (this.smooth) t = ease(t);
    b.position.lerpVectors(_va.fromArray(a.p), _vb.fromArray(c.p), t);
    _a.fromArray(a.q);
    _b.fromArray(c.q);
    b.quaternion.copy(_a).slerp(_b, t);
    b.scale.lerpVectors(_va.fromArray(a.s), _vb.fromArray(c.s), t);
  }

  toJSON() {
    return { fps: this.fps, length: this.length, smooth: this.smooth, tracks: Object.fromEntries(this.tracks) };
  }

  fromJSON(o) {
    this.fps = o.fps || 30;
    this.length = o.length || 120;
    this.smooth = o.smooth !== false;
    this.tracks = new Map(Object.entries(o.tracks || {}));
  }

  /** Build a three.js AnimationClip (bones addressed by uuid so odd bone names can't break binding). */
  toClip(boneMap) {
    const tracks = [];
    for (const [name, arr] of this.tracks) {
      const b = boneMap.get(name);
      if (!b) continue;
      const times = arr.map((k) => k.f / this.fps);
      tracks.push(new THREE.VectorKeyframeTrack(`${b.uuid}.position`, times, arr.flatMap((k) => k.p)));
      tracks.push(new THREE.QuaternionKeyframeTrack(`${b.uuid}.quaternion`, times, arr.flatMap((k) => k.q)));
      tracks.push(new THREE.VectorKeyframeTrack(`${b.uuid}.scale`, times, arr.flatMap((k) => k.s)));
    }
    return new THREE.AnimationClip('MiniPoseClip', Math.max(this.length - 1, 1) / this.fps, tracks);
  }
}
