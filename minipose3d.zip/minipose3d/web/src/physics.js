// Spring-bone physics (VRM-style). Not ragdoll: each simulated bone stays attached to its
// parent and is pulled back toward its rest pose by "stiffness", slowed by "drag", and
// pushed by gravity. Works on any chain or branching tree of bones you pick.
import * as THREE from 'three';

export const PRESETS = {
  hair: { stiffness: 0.9, drag: 0.35, gravity: 0.6, radius: 0.015 },
  skirt: { stiffness: 1.8, drag: 0.5, gravity: 0.8, radius: 0.03 },
};

const _m = new THREE.Matrix4();
const _inv = new THREE.Matrix4();
const _wp = new THREE.Vector3();
const _pp = new THREE.Vector3();
const _ps = new THREE.Vector3();
const _pq = new THREE.Quaternion();
const _q = new THREE.Quaternion();
const _inert = new THREE.Vector3();
const _stiff = new THREE.Vector3();
const _next = new THREE.Vector3();
const _to = new THREE.Vector3();
const _tw = new THREE.Vector3();
const _d = new THREE.Vector3();
const _t = new THREE.Vector3();
const DOWN = new THREE.Vector3(0, -1, 0);

/** World-space centre of a collider sphere: bone origin, slid toward its first child by `along` (0..1). */
export function colliderCenter(c, out) {
  out.setFromMatrixPosition(c.bone.matrixWorld);
  if (c.along > 0) {
    const child = c.bone.children.find((o) => o.isBone);
    if (child) out.lerp(_t.setFromMatrixPosition(child.matrixWorld), c.along);
  }
  return out;
}

export class SpringSystem {
  constructor() {
    this.groups = []; // { root, params, joints[] }
    this.colliders = []; // { bone, radius, along }
    this.unit = 1; // model height / 1.6 -> makes forces scale-independent
    this._acc = 0;
  }

  clear() {
    this.groups = [];
    this.colliders = [];
    this._acc = 0;
  }

  isSimulated(bone) {
    return this.groups.some((g) => g.joints.some((j) => j.bone === bone));
  }

  groupOf(bone) {
    return this.groups.find((g) => g.joints.some((j) => j.bone === bone)) || null;
  }

  /** Simulate `root` and every bone below it. The parent of `root` drives the chain. */
  add(root, params) {
    const joints = [];
    const visit = (b) => {
      joints.push(this._joint(b));
      for (const c of b.children) if (c.isBone) visit(c);
    };
    visit(root);
    const mine = new Set(joints.map((j) => j.bone));
    for (const g of this.groups) g.joints = g.joints.filter((j) => !mine.has(j.bone));
    this.groups = this.groups.filter((g) => g.joints.length);
    const group = { root, params: { ...params }, joints };
    this.groups.push(group);
    return group;
  }

  remove(bone) {
    const g = this.groupOf(bone);
    if (!g) return;
    for (const j of g.joints) {
      j.bone.quaternion.copy(j.restQ);
      j.bone.updateMatrix();
    }
    this.groups = this.groups.filter((x) => x !== g);
  }

  addCollider(bone, radius = 0.1, along = 0.5) {
    const c = { bone, radius, along };
    this.colliders.push(c);
    return c;
  }

  removeCollider(c) {
    this.colliders = this.colliders.filter((x) => x !== c);
  }

  _joint(b) {
    const restQ = b.userData.rest ? b.userData.rest.q.clone() : b.quaternion.clone();
    const tail = new THREE.Vector3();
    const kids = b.children.filter((c) => c.isBone);
    if (kids.length) {
      for (const k of kids) tail.add(k.position);
      tail.divideScalar(kids.length);
    }
    if (tail.lengthSq() < 1e-12) {
      // Leaf bone: extend along the direction it points away from its parent.
      tail.copy(b.position).applyQuaternion(_q.copy(restQ).invert());
      const len = Math.max(tail.length(), 0.04 * this.unit);
      if (tail.lengthSq() < 1e-12) tail.set(0, 1, 0);
      tail.normalize().multiplyScalar(len);
    }
    return {
      bone: b,
      restQ,
      tail,
      axis: tail.clone().normalize(),
      cur: new THREE.Vector3(),
      prev: new THREE.Vector3(),
    };
  }

  /** Snap every simulated bone back to rest and zero its velocity. */
  reset(root) {
    this._acc = 0;
    for (const g of this.groups) for (const j of g.joints) j.bone.quaternion.copy(j.restQ);
    if (root) root.updateMatrixWorld(true);
    for (const g of this.groups) {
      for (const j of g.joints) {
        j.cur.copy(j.tail).applyMatrix4(j.bone.matrixWorld);
        j.prev.copy(j.cur);
      }
    }
  }

  /** Call once per frame AFTER animation/gizmo poses are applied and root.updateMatrixWorld(true). */
  update(delta) {
    if (!this.groups.length) return;
    this._acc += Math.min(delta, 0.1);
    const step = 1 / 60;
    let n = 0;
    while (this._acc >= step && n < 4) {
      this._step(step);
      this._acc -= step;
      n++;
    }
    if (this._acc >= step) this._acc = 0;
  }

  _step(dt) {
    const cols = this.colliders.map((c) => ({
      c: colliderCenter(c, new THREE.Vector3()),
      r: c.radius * this.unit,
    }));

    for (const g of this.groups) {
      const p = g.params;
      for (const j of g.joints) {
        const b = j.bone;
        const par = b.parent;
        if (!par) continue;

        // Bone at rest rotation, under its (already updated) parent.
        _m.compose(b.position, j.restQ, b.scale);
        b.matrixWorld.multiplyMatrices(par.matrixWorld, _m);
        par.matrixWorld.decompose(_pp, _pq, _ps);
        _wp.setFromMatrixPosition(b.matrixWorld);
        _tw.copy(j.tail).applyMatrix4(b.matrixWorld);
        const lenW = _tw.distanceTo(_wp);

        _inert.subVectors(j.cur, j.prev).multiplyScalar(1 - p.drag);
        _stiff
          .copy(j.axis)
          .applyQuaternion(j.restQ)
          .applyQuaternion(_pq)
          .multiplyScalar(p.stiffness * dt * this.unit);
        _next
          .copy(j.cur)
          .add(_inert)
          .add(_stiff)
          .addScaledVector(DOWN, p.gravity * dt * this.unit);

        // Keep bone length constant.
        _next.sub(_wp).normalize().multiplyScalar(lenW).add(_wp);

        // Push out of collider spheres.
        for (const k of cols) {
          const minD = k.r + p.radius * this.unit;
          _d.subVectors(_next, k.c);
          const dist = _d.length();
          if (dist < minD) {
            _next.copy(k.c).addScaledVector(_d, minD / Math.max(dist, 1e-6));
            _next.sub(_wp).normalize().multiplyScalar(lenW).add(_wp);
          }
        }

        if (!Number.isFinite(_next.x + _next.y + _next.z)) _next.copy(_tw);
        j.prev.copy(j.cur);
        j.cur.copy(_next);

        // Convert the new tail position into a bone rotation.
        _inv.multiplyMatrices(par.matrixWorld, _m).invert();
        _to.copy(_next).applyMatrix4(_inv).normalize();
        _q.setFromUnitVectors(j.axis, _to);
        b.quaternion.copy(j.restQ).multiply(_q);
        b.updateMatrix();
        b.matrixWorld.multiplyMatrices(par.matrixWorld, b.matrix);
      }
    }
  }
}
