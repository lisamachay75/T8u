# MiniPose 3D

A small Prisma-3D-style pose/animation app for Android: import a rigged 3D model, pick any bone, move/rotate it, set keyframes, and switch on spring physics for hair and skirt bones. It keeps your original rig — bones are only posed, never added, removed or renamed (apart from de-duplicating identical bone names).

**Status: written but never compiled or run.** It was written in an environment with no Android SDK and no network, so nothing here has been built or tested. Expect a few build errors or bugs on the first run; send them back and they can be fixed.

## Get the APK (easiest: GitHub Actions)

1. Create a GitHub repo and upload this whole folder (keep `.github/` at the top level).
2. Repo → **Actions → Build APK → Run workflow**.
3. When it finishes, download the **MiniPose3D-apks** artifact. It contains:
   - `app-debug.apk` — signed with a debug key, installs right away for testing.
   - `app-release-unsigned.apk` — for you to sign with your own key.

### Sign the release APK

```
zipalign -p -f 4 app-release-unsigned.apk aligned.apk
keytool -genkeypair -v -keystore my.keystore -alias minipose -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks my.keystore --out MiniPose3D.apk aligned.apk
```

`zipalign` and `apksigner` come with Android SDK build-tools.

## Or build locally

Needs Node 20+, JDK 17, Android SDK (platform 35).

```
cd web && npm install && npm run build
rm -rf ../android/app/src/main/assets/www && mkdir -p ../android/app/src/main/assets
cp -r dist ../android/app/src/main/assets/www
cd ../android && gradle assembleDebug assembleRelease
```

(Or open `android/` in Android Studio after copying `web/dist` as above.) You can also try the editor on a PC with `cd web && npm run dev`.

## Using it

- **Import**: `.glb`, `.gltf` (self-contained), `.vrm`, `.fbx`. A `.json` project is loaded on top of the same model.
- **Select a bone**: tap a dot on the model, or use ☰ → Bones (search "hair", "arm", "eye"…). Pinch/zoom, **Focus** zooms to the bone; face bones are tiny, so zoom in.
- **Pose**: Move / Rotate / Scale gizmo on the selected bone, World/Local toggle, Reset bone.
- **Keyframes**: scrub the timeline, pose, tap **◆ Key** (stores that bone at that frame). **◇ Del** removes it. Play with ▶. "Key all bones" is in the Project tab.
- **Physics (manual, per bone)**: select the *first bone* of a hair strand or skirt panel → ☰ → Physics → *Hair* or *Skirt* preset. That bone and all its children become spring bones hanging from its parent; move the head/hips and they swing. Tune stiffness, drag, gravity, hit radius. Add **colliders** on thigh/leg bones so the skirt doesn't pass through legs. Physics bones can't be posed by hand or keyframed (their parent can).
- **Export GLB**: your original model with the rig intact plus your keyframes as an animation, saved to `Downloads/MiniPose3D`.

## Known limits

- Physics is real-time only; it is not baked into the exported animation.
- Exported animation uses linear interpolation (the in-app "smooth" easing is not exported).
- No undo, no multi-bone select, no Draco/KTX2-compressed models, glTF must be self-contained (use `.glb`).
- VRM-specific data (expressions, MToon materials) is not preserved on export.
